package construction;
public interface ConstructionVehicleInterface {
    public void work();

    public void maintain();

    public void stopWorking();
}