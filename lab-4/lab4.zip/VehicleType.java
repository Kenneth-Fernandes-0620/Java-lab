public enum VehicleType {
    DIGGER,
    CRANE,
    TRUCK,
}
