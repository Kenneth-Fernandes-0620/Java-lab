package construction;
public enum VehicleType {
    DIGGER,
    CRANE,
    TRUCK,
}
